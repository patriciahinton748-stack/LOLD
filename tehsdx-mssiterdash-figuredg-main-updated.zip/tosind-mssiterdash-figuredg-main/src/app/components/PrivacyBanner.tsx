'use client';
import { useState, useEffect } from 'react';

interface PrivacyBannerProps {
  onAccept?: () => void;
  onDecline?: () => void;
}

export default function PrivacyBanner( { onAccept, onDecline }: PrivacyBannerProps ) {
  const [ isVisible, setIsVisible ] = useState( false );
  const [ isAnimating, setIsAnimating ] = useState( false );

  useEffect( () => {
    // Check if user has already made a choice
    const consent = localStorage.getItem( 'privacy-consent' );
    if ( !consent ) {
      setTimeout( () => setIsVisible( true ), 2000 ); // Show after 2 seconds
    }
  }, [] );

  const handleAccept = () => {
    setIsAnimating( true );
    localStorage.setItem( 'privacy-consent', 'accepted' );
    localStorage.setItem( 'privacy-consent-date', new Date().toISOString() );

    setTimeout( () => {
      setIsVisible( false );
      onAccept?.();
    }, 300 );
  };

  const handleDecline = () => {
    setIsAnimating( true );
    localStorage.setItem( 'privacy-consent', 'declined' );
    localStorage.setItem( 'privacy-consent-date', new Date().toISOString() );

    setTimeout( () => {
      setIsVisible( false );
      onDecline?.();
    }, 300 );
  };

  if ( !isVisible ) return null;

  return (
    <div className={ `fixed bottom-0 left-0 right-0 z-50 transform transition-transform duration-300 ${isAnimating ? 'translate-y-full' : 'translate-y-0'
      }` }>
      <div className="bg-white border-t border-gray-300 shadow-lg">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 p-4">
          <div className="flex-1">
            <p className="text-sm text-gray-800 leading-relaxed">
              We use cookies and similar technologies to enhance your experience, analyze site usage,
              and assist in our security efforts. By continuing to use this site, you consent to our
              <a href="/privacy" className="text-[#0068b8] hover:text-[#23689d] hover:underline ml-1">
                Privacy Policy
              </a> and
              <a href="/terms" className="text-[#0068b8] hover:text-[#23689d] hover:underline ml-1">
                Terms of Service
              </a>.
            </p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={ handleDecline }
              className="px-6 py-1 text-sm border border-gray-500 bg-white text-gray-800 hover:bg-gray-50 transition-colors"
            >
              Decline
            </button>
            <button
              onClick={ handleAccept }
              className="px-6 py-1 text-sm bg-[#0068b8] text-white hover:bg-[#23689d] transition-colors"
            >
              Accept All
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}