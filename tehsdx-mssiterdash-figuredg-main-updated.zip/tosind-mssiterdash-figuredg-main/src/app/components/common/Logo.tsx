import React from "react";
import Image from "next/image";
import { Box } from "@mantine/core";
import img from '../../assets/imgs/logo.png'

type Props = { className?: string }

export default function Logo({ className }: Props) {
  return (
    <Box>
      <Image
        priority
        src={img}
        alt="logo icon"
        className={className}
      />
    </Box>
  )
}