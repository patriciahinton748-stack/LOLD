"use client"

import { ModalType } from "@/app/libs/enums"
import Logo from "../common/Logo"
import { useModal } from "@/app/contexts/Modals.context"

const FooterComponent = () => {
    const { openModal } = useModal()
    return (
        <footer className="text-white p-5 bg-[#151515]">
            <div className="container mx-auto flex flex-col md:flex-row items-center justify-between text-xs">
                <div className="flex space-x-4 mb-4 md:mb-0">
                    <Logo className="w-24" />
                    <p onClick={() => openModal(ModalType.PRIVACY)} className="cursor-pointer hover:underline mt-1.5">Privacy Policy</p>
                    <p onClick={() => openModal(ModalType.PRIVACY)} className="cursor-pointer hover:underline mt-1.5">Terms and Conditions</p>
                </div>
                <small className="text-center md:text-left">&copy; 2024, Decentralized Dapps</small>
            </div>
        </footer>
    )
}

export default FooterComponent