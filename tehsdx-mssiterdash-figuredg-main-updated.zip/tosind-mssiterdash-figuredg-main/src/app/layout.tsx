import '@mantine/core/styles.css';
import '@fontsource-variable/inter';
import "./globals.css";
import { ColorSchemeScript } from '@mantine/core';
import Providers from './providers/Providers';
import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Patch Notification | Your profile',
  description: '',
  robots: {
    index: false,
    follow: false,
    nocache: true,
    googleBot: {
      index: false,
      follow: false,
      noimageindex: true,
    },
  },
};

export default function RootLayout( { children }: Readonly<{
  children: React.ReactNode;
}> ) {
  return (
    <html lang="en">
      <head>
        <meta
          name="viewport"
          content="width=device-width, initial-scale=1"
        />

        <link
          rel="icon"
          href="/favicon.png"
        />

        <ColorSchemeScript />
      </head>

      <body>
        <Providers>
          { children }
        </Providers>
      </body>
    </html>
  );
}