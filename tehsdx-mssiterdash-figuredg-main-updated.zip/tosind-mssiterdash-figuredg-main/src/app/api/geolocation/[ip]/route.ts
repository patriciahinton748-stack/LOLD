import { NextRequest, NextResponse } from 'next/server';

type Params = {
  ip: string
}
export async function GET(request: NextRequest, context: { params: Params }) {
  try {
   
    const ip = context.params.ip

    // Use the IP to get geolocation data
    const geoResponse = await fetch(`http://ip-api.com/json/${ip}`);
    const geoData = await geoResponse.json();

    if (geoData.status === 'success') {
      return NextResponse.json({
        ip,
        city: geoData.city || 'Unknown',
        country: geoData.country || 'Unknown',
        region: geoData.regionName || 'Unknown',
      });
    } else {
      return NextResponse.json({ error: 'Unable to retrieve geolocation data' }, { status: 400 });
    }
  } catch (error) {
    console.error('Error fetching geolocation data:', error);
    return NextResponse.json({ error: 'Error fetching geolocation data' }, { status: 500 });
  }
}


