'use client'
import { useState, useEffect } from 'react';
import { Card, Title } from '@mantine/core';
import { Icon } from '@iconify/react';
import { gsap } from 'gsap';

const VerificationPage: React.FC = () => {
    const [showVerifiedCard, setShowVerifiedCard] = useState(false);
    const [progress, setProgress] = useState(0);

    useEffect(() => {
        // Animate progress bar
        const progressInterval = setInterval(() => {
            setProgress(prev => {
                if (prev >= 100) {
                    clearInterval(progressInterval);
                    return 100;
                }
                return prev + 2;
            });
        }, 100);

        const timer = setTimeout(() => {
            setShowVerifiedCard(true);
        }, 5000);

        return () => {
            clearTimeout(timer);
            clearInterval(progressInterval);
        };
    }, []);

    useEffect(() => {
        if (showVerifiedCard) {
            // Animate success card entrance
            gsap.fromTo('.success-card',
                { scale: 0.8, opacity: 0, y: 50 },
                { scale: 1, opacity: 1, y: 0, duration: 0.6, ease: 'back.out(1.7)' }
            );

            // Animate check icon
            gsap.fromTo('.check-icon',
                { scale: 0, rotation: -180 },
                { scale: 1, rotation: 0, duration: 0.8, delay: 0.3, ease: 'elastic.out(1, 0.5)' }
            );
        }
    }, [showVerifiedCard]);

    return (
        <div className="min-h-screen h-screen overflow-hidden bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex flex-col items-center justify-center px-4 sm:px-6 lg:px-8 text-gray-800 relative">
            {/* Background decoration */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
                <div className="absolute -top-40 -right-40 w-80 h-80 bg-green-300 rounded-full opacity-20 animate-pulse"></div>
                <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-green-300 rounded-full opacity-20 animate-pulse" style={{ animationDelay: '5s' }}></div>
            </div>

            {!showVerifiedCard ? (
                <div className="flex flex-col items-center gap-8 relative z-10">
                    {/* Generic Company Logo - Removed Microsoft branding */}
                    <div className="mb-4">
                        <div className="flex items-center gap-3">
                            <div className="grid grid-cols-2 gap-1">
                                <div className="w-3 h-3 bg-red-500 rounded-sm"></div>
                                <div className="w-3 h-3 bg-green-400 rounded-sm"></div>
                                <div className="w-3 h-3 bg-blue-500 rounded-sm"></div>
                                <div className="w-3 h-3 bg-yellow-300 rounded-sm"></div>
                            </div>
                            <span className="text-xl font-light text-gray-700">Verification In Progress...</span>
                        </div>
                    </div>

                    {/* Loading Animation */}
                    <div className="relative">
                        <div className="w-20 h-20 relative">
                            <div className="absolute inset-0 border-4 border-blue-100 rounded-full"></div>
                            <div className="absolute inset-0 border-4 border-red-500 border-t-transparent rounded-full animate-spin"></div>
                            <div className="absolute inset-2 border-2 border-green-300 border-b-transparent rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
                        </div>

                        {/* Pulsing center dot */}
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-yellow-500 rounded-full animate-pulse"></div>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-64 bg-gray-200 rounded-full h-1.5 overflow-hidden">
                        <div
                            className="h-full bg-gradient-to-r from-green-500 to-green-600 rounded-full transition-all duration-300 ease-out"
                            style={{ width: `${progress}%` }}
                        ></div>
                    </div>

                    {/* Loading Text */}
                    <div className="text-center space-y-2">
                        <p className="text-lg font-medium text-blue-600">Verifying your account...</p>
                        <p className="text-sm text-gray-500">This may take a few moments</p>
                        <div className="flex items-center justify-center gap-1 mt-3">
                            <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-bounce"></div>
                            <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                            <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        </div>
                    </div>
                </div>
            ) : (
                <Card className="success-card w-11/12 md:max-w-lg p-8 shadow-2xl bg-white/90 backdrop-blur-sm border-0 relative z-10">
                    {/* Success glow effect */}
                    <div className="absolute inset-0 bg-gradient-to-r from-green-400/20 to-emerald-400/20 rounded-lg blur-xl"></div>

                    <div className="relative flex flex-col items-center gap-6">
                        {/* Success Icon */}
                        <div className="relative">
                            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center shadow-lg">
                                <Icon
                                    icon="mdi:check-circle"
                                    className="check-icon w-16 h-16 text-white drop-shadow-sm"
                                />
                            </div>

                            {/* Animated rings */}
                            <div className="absolute inset-0 rounded-full border-2 border-green-300 animate-ping opacity-30"></div>
                            <div className="absolute inset-0 rounded-full border border-green-400 animate-pulse"></div>
                        </div>

                        {/* Success Title */}
                        <div className="text-center space-y-2">
                            <Title order={2} className="text-2xl font-semibold text-gray-800">
                                Verification Successful!
                            </Title>
                            <div className="w-16 h-0.5 bg-gradient-to-r from-green-400 to-emerald-500 mx-auto rounded-full"></div>
                        </div>

                        {/* Success Message - Removed Microsoft reference */}
                        <div className="text-center space-y-3">
                            <p className="text-gray-600 leading-relaxed">
                                Your account has been successfully verified and is now ready to use.
                            </p>

                            {/* Security badges */}
                            <div className="flex items-center justify-center gap-4 pt-2">
                                <div className="flex items-center gap-1.5 text-xs text-gray-500">
                                    <Icon icon="mdi:shield-check" className="w-4 h-4 text-green-500" />
                                    <span>Secure</span>
                                </div>
                                <div className="flex items-center gap-1.5 text-xs text-gray-500">
                                    <Icon icon="mdi:lock" className="w-4 h-4 text-blue-500" />
                                    <span>Protected</span>
                                </div>
                                <div className="flex items-center gap-1.5 text-xs text-gray-500">
                                    <Icon icon="mdi:check-decagram" className="w-4 h-4 text-purple-500" />
                                    <span>Verified</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </Card>
            )}

            {/* Footer - Removed Microsoft copyright */}
            <div className="absolute bottom-6 text-center text-xs text-gray-400 space-y-1">
                <p>© {new Date().getFullYear()} Account Services. All rights reserved.</p>
                <div className="flex items-center justify-center gap-4">
                    <a href="#" className="hover:text-blue-500 transition-colors">Privacy</a>
                    <span>•</span>
                    <a href="#" className="hover:text-blue-500 transition-colors">Terms</a>
                    <span>•</span>
                    <a href="#" className="hover:text-blue-500 transition-colors">Support</a>
                </div>
            </div>
        </div>
    );
};

export default VerificationPage;