"use client"
import React, { createContext, useContext, useState } from 'react';
import { ModalType } from '../libs/enums';


interface ModalProps {
  children: React.ReactNode;
}

interface ModalContextType {
  // modal state types
  isConnectModal: boolean;
  isPrivacyModal: boolean;
  isResponseModal: boolean;

  openModal: ( type: ModalType ) => void;
  closeModal: ( type: ModalType ) => void;
}


const ModalContext = createContext<ModalContextType | undefined>(undefined);

export const ModalProvider: React.FC<ModalProps> = ({ children }) => {
  const [ isPrivacyModal, setIsPrivacyModal ] = useState<boolean>(false);
  const [ isConnectModal, setIsConnectModal ] = useState<boolean>( false );
    const [ isResponseModal, setIsResponseModal ] = useState<boolean>(false);


  const openModal = (type: ModalType) => {
    type === ModalType.CONNECT && setIsConnectModal( true );
    type === ModalType.PRIVACY && setIsPrivacyModal( true );
    type === ModalType.RESPONSE && setIsResponseModal( true );
  };
  
  const closeModal = (type: ModalType) => {
     type === ModalType.CONNECT && setIsConnectModal( false );
    type === ModalType.PRIVACY && setIsPrivacyModal( false );
     type === ModalType.RESPONSE && setIsResponseModal( false );
  };

  const contextValue: ModalContextType = {
    openModal,
    closeModal,
    isPrivacyModal,
    isConnectModal,
    isResponseModal
  };

  return (
    <ModalContext.Provider value={contextValue}>
      {children}
    </ModalContext.Provider>
  );
};

export const useModal = () => {
  const context = useContext(ModalContext);

  if (!context) {
    throw new Error('useModal must be used within ModalProvider');
  }

  return context;
};