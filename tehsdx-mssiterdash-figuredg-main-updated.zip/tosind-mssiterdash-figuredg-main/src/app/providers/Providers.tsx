"use client"
import React, { ReactNode } from 'react';
import { ModalProvider } from '../contexts/Modals.context';
import { MantineProvider } from '@mantine/core';

interface ProvidersProps {
  children: ReactNode;
}

const Providers: React.FC<ProvidersProps> = ({ children }) => (
  <MantineProvider theme={{
    fontFamily: "Inter Variable, sans-serif",
  }}>
    <ModalProvider>
      {children}
    </ModalProvider>
  </MantineProvider>

);

export default Providers;