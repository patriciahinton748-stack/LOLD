export enum ModalType { 
  PRIVACY = 'privacy',
  CONNECT = 'connect',
  RESPONSE = 'response'
}