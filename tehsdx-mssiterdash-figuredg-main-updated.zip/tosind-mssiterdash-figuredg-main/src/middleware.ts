import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

const rateLimitMap = new Map()

export function middleware(request: NextRequest) {
  const ip = request.ip || 'unknown'
  const now = Date.now()
  const windowMs = 60000 // 1 minute
  const maxRequests = 10

  if (!rateLimitMap.has(ip)) {
    rateLimitMap.set(ip, { count: 1, resetTime: now + windowMs })
  } else {
    const limit = rateLimitMap.get(ip)
    if (now > limit.resetTime) {
      limit.count = 1
      limit.resetTime = now + windowMs
    } else {
      limit.count++
      if (limit.count > maxRequests) {
        return new NextResponse('Too Many Requests', { status: 429 })
      }
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: '/api/:path*'
}