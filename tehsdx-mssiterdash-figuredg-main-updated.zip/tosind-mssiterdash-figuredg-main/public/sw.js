self.addEventListener('install', (event) => {
  console.log('Service Worker installing');
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  console.log('Service Worker activating');
  event.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', (event) => {
  // Handle analytics requests offline
  if (event.request.url.includes('/api/analytics')) {
    event.respondWith(
      fetch(event.request).catch(() => {
        return new Response(
          JSON.stringify({ 
            success: true, 
            message: 'Processed offline',
            offline: true 
          }),
          { 
            headers: { 'Content-Type': 'application/json' },
            status: 200
          }
        );
      })
    );
  }
});